using AspDotNetCoreLearn.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace AspDotNetCoreLearn.Pages.StudentList
{
    public class IndexModel : PageModel
    {
        //public string myStringConnection = "Data Source=DESKTOP-FA5HHDK; initial catalog=Empdb; integrated security=True";
        public List<Student> lstStudents = new List<Student>();
        AppDbContext appDbContext;
        public IndexModel(AppDbContext db)
        {
            appDbContext = db;
        }
        public void OnGet()
        {
            lstStudents=appDbContext.StuList.ToList();

            //SqlConnection conn = new SqlConnection(myStringConnection);
            
            //SqlCommand cmd = new SqlCommand("select * from project", conn);
            //conn.Open();
            //SqlDataReader dr = cmd.ExecuteReader();
            //while (dr.Read())
            //{
            //    int id = Convert.ToInt16(dr["id"]);
            //    string name = Convert.ToString(dr["name"]);
            //    string course = Convert.ToString(dr["course"]);
            //    lstStudents.Add(new Student(id, name, course));
            //}
            //conn.Close();
            
        }
        //lstStudents.Add(new Student(101, "Mohit", "Dot net"));
        //lstStudents.Add(new Student(102, "Sumit", "Python"));
        //lstStudents.Add(new Student(103, "Ankit", "Java"));

    }
    
}
 