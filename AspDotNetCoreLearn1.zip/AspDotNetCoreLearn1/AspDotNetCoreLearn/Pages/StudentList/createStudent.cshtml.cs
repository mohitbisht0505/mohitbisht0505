using AspDotNetCoreLearn.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace AspDotNetCoreLearn.Pages.StudentList
{
    public class createStudentModel : PageModel
    {
        public void OnGet()
        {
            
        }
        protected void Btn_Sub(object sender, EventArgs e)
        {   

      //      SqlCommand command;
      //      SqlDataAdapter adapter = new SqlDataAdapter();
      //      String sql;
      //      sql = "Insert into project(id,name,course) value(106,'Rohit','MERN' )";
      //          SqlConnection conn = new SqlConnection(sql);


      //      command = new SqlCommand(sql, conn);
      //      adapter.InsertCommand = new SqlCommand(sql, conn);
      //      adapter.InsertCommand.ExecuteNonQuery();

      //      command.Dispose();
		    //conn.Close();

        }

    }

}
