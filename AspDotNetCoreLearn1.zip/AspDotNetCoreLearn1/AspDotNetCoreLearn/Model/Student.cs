﻿namespace AspDotNetCoreLearn.Model
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Course { get; set; }

        public Student()
        {

        }
        public Student(int id, string name, string course)
        {
            Id = id;
            Name = name;
            Course = course;
            
        }
    }

}
