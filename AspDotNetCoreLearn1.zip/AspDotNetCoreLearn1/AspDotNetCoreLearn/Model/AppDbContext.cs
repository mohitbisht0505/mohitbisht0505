﻿using Microsoft.EntityFrameworkCore;

namespace AspDotNetCoreLearn.Model
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
       public DbSet<Student> StuList { get; set; }
    }

}
