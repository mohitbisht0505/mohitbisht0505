﻿// See https://aka.ms/new-console-template for more information
using LinqStudy;
#region createData
IList<Student> studentList = new List<Student>();


Student student1 = new Student() { StudentID = 1, StudentName = "Moin" };
student1.EnrolledCourses.Add(new Course { CourseID = 1, CourseName = "Java" });
student1.EnrolledCourses.Add(new Course { CourseID = 2, CourseName = "Dotnet" });

Student student2 = new Student() { StudentID = 2, StudentName = "Mohit" };
student2.EnrolledCourses.Add(new Course { CourseID = 1, CourseName = "Java" });

Student student3 = new Student() { StudentID = 3, StudentName = "Mohit" };
student3.EnrolledCourses.Add(new Course { CourseID = 3, CourseName = "Python" });
studentList.Add(student1);
studentList.Add(student2);
studentList.Add(student3);

#endregion


#region where
//var result=studentList.Where(x => x.StudentName.StartsWith('M'));

//foreach(var item in result)
//{
//    Console.WriteLine(item.StudentName);
//}
#endregion
#region select

//var stuList=studentList.Select(x => x.EnrolledCourses);
//foreach (var itemList in stuList)
//{
//    foreach (var item in itemList)
//    {
//        Console.WriteLine(item.CourseName);

//    }
//Console.WriteLine(itemList);
//}
//var stuList = studentList.SelectMany(x => x.EnrolledCourses);
//foreach (var item in stuList)
//{

//    Console.WriteLine(item.CourseName);
//}

#endregion

#region firstordefault

//var stu=studentList.First(x => x.StudentName=="Divya");
//var stu1 = studentList.FirstOrDefault(x => x.StudentName == "Divya");

//Console.WriteLine(stu1.StudentName);
//Console.WriteLine(stu.StudentName);

#endregion
#region lastAndLastOrDefault



#endregion

#region singleOrDefault

var stu=studentList.SingleOrDefault(x => x.StudentName == "Divya");


#endregion
Console.ReadLine();